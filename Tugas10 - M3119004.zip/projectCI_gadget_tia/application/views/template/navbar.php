<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= base_url(); ?>">Toekoe Hape</a>
    <nav class="navbar-nav ms-auto justify-content-center align-items-center px-5">
      <a href="<?= base_url('index.php/admin'); ?>" class="nav-link">Login</a>
    </nav>
  </div>
</nav>