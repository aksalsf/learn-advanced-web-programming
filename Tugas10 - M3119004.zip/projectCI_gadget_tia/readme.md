# Project CI - Gadget - TI A

Repositori untuk proyek PHP dengan framework CodeIgniter 3.

## Anggota Kelompok

1.  M3119002 - Adhani Rahma Putri
2.  M3119004 - Aksal Syah Falah
3.  M3119005 - Almiraluthfi Pratiwi
4.  M3119006 - Aldan Maulana Fajri

## Cara Instalasi

1.  Buka file `application/config/config.php`
2.  Ubah nilai dari variabel `$config['base_url']` menjadi `localhost_kamu/projectCI_gadget_tia/`
3.  Akses aplikasi melalui peramban web dengan URL `localhost_kamu/projectCI_gadget_tia/`

## Admin

Email: admin@tkhp.com
Password: admin
